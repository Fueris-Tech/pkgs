import * as React from "react";
declare const MenuItems: ({ menus, depthLevel, currentMenu }: {
    menus: any;
    depthLevel: number;
    currentMenu: any;
}) => React.JSX.Element;
export default MenuItems;
//# sourceMappingURL=menuitems.d.ts.map