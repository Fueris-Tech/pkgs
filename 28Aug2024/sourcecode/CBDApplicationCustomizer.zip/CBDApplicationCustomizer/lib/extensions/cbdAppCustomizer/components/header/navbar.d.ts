import * as React from "react";
declare const Navbar: ({ menus }: {
    menus: any[];
}) => React.JSX.Element;
export default Navbar;
//# sourceMappingURL=navbar.d.ts.map