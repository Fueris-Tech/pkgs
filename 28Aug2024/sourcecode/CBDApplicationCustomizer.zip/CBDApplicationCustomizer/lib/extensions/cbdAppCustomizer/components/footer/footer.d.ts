import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
import * as React from "react";
import "./../../../../tailwind.css";
export interface IFooter {
    context: ApplicationCustomizerContext;
    footerSiteUrl: string;
}
export declare const Footer: React.FunctionComponent<IFooter>;
//# sourceMappingURL=footer.d.ts.map