import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
import * as React from "react";
import "./../../../../tailwind.css";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
export interface IHeader {
    context: ApplicationCustomizerContext;
    headerSiteUrl: string;
}
export declare const Header: React.FunctionComponent<IHeader>;
//# sourceMappingURL=header.d.ts.map