import * as React from "react";
declare const Dropdown: ({ menus, submenus, dropdown, depthLevel }: any) => React.JSX.Element;
export default Dropdown;
//# sourceMappingURL=dropdown.d.ts.map