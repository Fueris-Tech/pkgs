import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
export interface ICbdAppCustomizerApplicationCustomizerProperties {
    cssurl: string;
    headerSiteUrl: string;
}
export default class CbdAppCustomizerApplicationCustomizer extends BaseApplicationCustomizer<ICbdAppCustomizerApplicationCustomizerProperties> {
    private header;
    private hidecss;
    private getHeaderUrlFromList;
    onInit(): Promise<void>;
    private bootstrap;
    private _onDispose;
}
//# sourceMappingURL=CbdAppCustomizerApplicationCustomizer.d.ts.map