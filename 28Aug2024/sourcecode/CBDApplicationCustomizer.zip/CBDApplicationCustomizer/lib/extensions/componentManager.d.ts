import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
export default class ComponentManager {
    static renderHeader(context: ApplicationCustomizerContext, headerSiteUrl: string, element: HTMLElement): void;
    static renderFooter(context: ApplicationCustomizerContext, footerSiteUrl: string, element: HTMLElement): void;
    static _dispose(element: HTMLElement): void;
}
//# sourceMappingURL=componentManager.d.ts.map